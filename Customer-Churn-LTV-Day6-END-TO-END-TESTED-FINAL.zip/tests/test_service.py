from app.core.config import Settings
from app.models.schemas import CustomerFeatures
from app.services.prediction_service import PredictionService

def make(contract='Month-to-month',tenure=3,charge=100):
    return CustomerFeatures(customer_id='X',tenure_months=tenure,monthly_charges=charge,total_charges=300,contract=contract,internet_service='Fiber optic',payment_method='Electronic check')
def test_high_risk_profile_has_higher_baseline():
    s=PredictionService(Settings()); assert s.predict_churn(make()).churn_probability>s.predict_churn(make('Two year',60,40)).churn_probability
def test_ltv_non_negative(): assert PredictionService(Settings()).predict_ltv(make()).estimated_ltv>=0
def test_explanation_contains_factors(): assert PredictionService(Settings()).explain(make())['factors']
