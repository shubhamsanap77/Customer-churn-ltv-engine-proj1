from app.core.config import Settings
from app.models.schemas import CustomerFeatures
from app.services.prediction_service import PredictionService


def customer(**overrides):
    data = dict(
        customer_id="EDGE-1",
        tenure_months=0,
        monthly_charges=0,
        total_charges=0,
        contract="Two year",
        internet_service="No",
        payment_method="Bank transfer",
    )
    data.update(overrides)
    return CustomerFeatures(**data)


def test_baseline_probability_is_always_bounded():
    service = PredictionService(Settings())
    for contract in ("Month-to-month", "One year", "Two year"):
        for tenure in (0, 1, 12, 48, 600):
            result = service.predict_churn(customer(contract=contract, tenure_months=tenure, monthly_charges=1_000_000))
            assert 0.0 <= result.churn_probability <= 1.0


def test_zero_value_customer_has_non_negative_ltv():
    result = PredictionService(Settings()).predict_ltv(customer())
    assert result.estimated_ltv == 0


def test_explanation_discloses_baseline_limitations():
    result = PredictionService(Settings()).explain(customer(contract="Month-to-month", tenure_months=3))
    assert "not SHAP" in result["disclaimer"]
    assert result["base_risk"] >= 0
