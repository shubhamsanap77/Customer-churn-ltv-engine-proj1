"""Day 6 end-to-end pipeline tests.

These tests exercise the production path rather than isolated functions:
client -> middleware -> validation -> service -> persistence -> history.
"""
import pytest

from app.core.config import get_settings
from app.core.middleware import InMemoryRateLimitMiddleware


@pytest.fixture(autouse=True)
def reset_rate_limiter():
    InMemoryRateLimitMiddleware.buckets.clear()
    yield
    InMemoryRateLimitMiddleware.buckets.clear()


def test_full_prediction_pipeline_is_traceable(client, customer):
    request_id = "day6-e2e-001"
    response = client.post(
        "/api/v1/predict",
        json=customer,
        headers={"X-Request-ID": request_id},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["request_id"] == request_id
    assert body["customer_id"] == customer["customer_id"]
    assert 0 <= body["churn"]["churn_probability"] <= 1
    assert body["ltv"]["estimated_ltv"] >= 0
    assert response.headers["X-Request-ID"] == request_id
    assert float(response.headers["X-Process-Time-ms"]) >= 0

    history = client.get("/api/v1/predictions/history")
    assert history.status_code == 200
    assert history.json()[0]["request_id"] == request_id
    assert history.json()[0]["customer_id"] == customer["customer_id"]


def test_batch_is_atomic_when_prediction_fails(client, customer, monkeypatch):
    from app.api import routes
    from app.services.prediction_service import PredictionService as RealPredictionService

    class FailingService:
        def predict(self, item):
            if item.customer_id == "FAIL":
                raise RuntimeError("simulated model failure")
            return RealPredictionService(get_settings()).predict(item)

    monkeypatch.setattr(routes, "PredictionService", lambda settings: FailingService())

    payload = {
        "customers": [
            customer,
            {**customer, "customer_id": "FAIL"},
        ]
    }
    from fastapi.testclient import TestClient
    from app.main import app

    isolated_client = TestClient(app, raise_server_exceptions=False)
    response = isolated_client.post("/api/v1/predict/batch", json=payload)
    assert response.status_code == 500

    history = isolated_client.get("/api/v1/predictions/history")
    assert history.status_code == 200
    assert history.json() == []


def test_batch_success_persists_all_records_in_one_request(client, customer):
    payload = {
        "customers": [
            customer,
            {**customer, "customer_id": "CUST-1002", "tenure_months": 50},
            {**customer, "customer_id": "CUST-1003", "contract": "Two year"},
        ]
    }
    response = client.post(
        "/api/v1/predict/batch",
        json=payload,
        headers={"X-Request-ID": "batch-001"},
    )
    assert response.status_code == 200
    assert response.json()["count"] == 3
    assert {x["customer_id"] for x in response.json()["predictions"]} == {
        "CUST-1001", "CUST-1002", "CUST-1003"
    }

    history = client.get("/api/v1/predictions/history?limit=100")
    assert len(history.json()) == 3
    assert {x["customer_id"] for x in history.json()} == {
        "CUST-1001", "CUST-1002", "CUST-1003"
    }


def test_validation_rejects_missing_and_out_of_range_fields(client, customer):
    missing = dict(customer)
    del missing["customer_id"]
    assert client.post("/api/v1/predict", json=missing).status_code == 422

    out_of_range = {**customer, "tenure_months": 601}
    response = client.post("/api/v1/predict", json=out_of_range)
    assert response.status_code == 422
    assert response.json()["error"] == "validation_error"
    assert response.json()["request_id"]


def test_batch_schema_enforces_maximum_size(client, customer):
    oversized = {**customer, "customer_id": "X"}
    response = client.post(
        "/api/v1/predict/batch",
        json={"customers": [oversized] * 1001},
    )
    assert response.status_code == 422


def test_api_key_rejection_and_acceptance(client, customer, monkeypatch):
    monkeypatch.setenv("API_KEY_ENABLED", "true")
    monkeypatch.setenv("API_KEY", "day6-secret")

    # get_settings is cached, so clear it to load the temporary security config.
    get_settings.cache_clear()
    try:
        assert client.post("/api/v1/predict", json=customer).status_code == 401
        accepted = client.post(
            "/api/v1/predict",
            json=customer,
            headers={"X-API-Key": "day6-secret"},
        )
        assert accepted.status_code == 200
    finally:
        monkeypatch.setenv("API_KEY_ENABLED", "false")
        get_settings.cache_clear()


def test_rate_limit_returns_retry_after_header(client, customer, monkeypatch):
    monkeypatch.setenv("RATE_LIMIT_ENABLED", "true")
    monkeypatch.setenv("RATE_LIMIT_PER_MINUTE", "1")
    get_settings.cache_clear()
    try:
        assert client.get("/ready").status_code == 200
        blocked = client.get("/ready")
        assert blocked.status_code == 429
        assert blocked.headers["Retry-After"] == "60"
    finally:
        monkeypatch.setenv("RATE_LIMIT_ENABLED", "true")
        monkeypatch.setenv("RATE_LIMIT_PER_MINUTE", "120")
        get_settings.cache_clear()
