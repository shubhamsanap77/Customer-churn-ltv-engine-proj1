def test_root(client):
    r=client.get('/'); assert r.status_code==200; assert r.json()['docs']=='/docs'
def test_health(client):
    r=client.get('/api/v1/health'); assert r.status_code==200; assert r.json()['database']=='ok'
def test_request_id(client):
    r=client.get('/',headers={'X-Request-ID':'test-123'}); assert r.headers['X-Request-ID']=='test-123'
def test_combined_prediction_persists(client,customer):
    r=client.post('/api/v1/predict',json=customer); assert r.status_code==200; assert r.json()['request_id'];
    h=client.get('/api/v1/predictions/history'); assert h.status_code==200; assert h.json()[0]['customer_id']=='CUST-1001'
def test_churn(client,customer):
    r=client.post('/api/v1/predict/churn',json=customer); assert r.status_code==200; assert 0<=r.json()['churn_probability']<=1
def test_ltv(client,customer):
    r=client.post('/api/v1/predict/ltv',json=customer); assert r.status_code==200; assert r.json()['estimated_ltv']>0
def test_batch(client,customer):
    second={**customer,'customer_id':'CUST-1002','tenure_months':50}
    r=client.post('/api/v1/predict/batch',json={'customers':[customer,second]}); assert r.status_code==200; assert r.json()['count']==2
def test_explain(client,customer):
    r=client.post('/api/v1/explain',json=customer); assert r.status_code==200; assert 'factors' in r.json()
def test_invalid_payload(client,customer):
    bad={**customer,'monthly_charges':-1}; r=client.post('/api/v1/predict',json=bad); assert r.status_code==422; assert r.json()['error']=='validation_error'
def test_invalid_contract(client,customer):
    bad={**customer,'contract':'weekly'}; assert client.post('/api/v1/predict',json=bad).status_code==422
