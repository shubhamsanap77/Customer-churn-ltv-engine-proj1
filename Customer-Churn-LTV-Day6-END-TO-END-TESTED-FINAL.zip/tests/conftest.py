import os
os.environ['DATABASE_URL']='sqlite:///./test_customer_engine.db'
os.environ['API_KEY_ENABLED']='false'
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.db.database import Base, engine

@pytest.fixture(autouse=True)
def clean_db():
    Base.metadata.drop_all(bind=engine); Base.metadata.create_all(bind=engine); yield

@pytest.fixture
def client(): return TestClient(app)
@pytest.fixture
def customer():
    return {'customer_id':'CUST-1001','tenure_months':8,'monthly_charges':95.5,'total_charges':764,'contract':'Month-to-month','internet_service':'Fiber optic','senior_citizen':False,'partner':False,'dependents':False,'payment_method':'Electronic check'}
