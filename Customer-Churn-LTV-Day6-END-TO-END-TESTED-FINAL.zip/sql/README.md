# SQL
PostgreSQL schemas, migrations and analytical SQL can be added here. The Day 5 API uses SQLAlchemy and can switch from SQLite to PostgreSQL through `DATABASE_URL`.
