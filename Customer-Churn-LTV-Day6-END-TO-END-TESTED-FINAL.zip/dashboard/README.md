# Dashboard
Dashboard clients can consume `/api/v1/predict`, `/api/v1/predict/batch`, `/api/v1/predictions/history`, and `/api/v1/health`.
