# Customer Churn Prediction & Lifetime Value Engine
## Day 5 — Advanced API / Backend Integration & Testing

This Day 5 implementation turns the original project skeleton into a structured, testable backend service suitable for connecting an ML model, dashboard, database and future deployment pipeline.

### Day 5 deliverables
- FastAPI REST backend with `/api/v1` versioning
- Pydantic validation and consistent JSON errors
- Churn prediction endpoint
- LTV prediction endpoint
- Combined prediction endpoint
- Batch prediction endpoint
- Prediction history persisted through SQLAlchemy
- SQLite development database with PostgreSQL-ready configuration
- Request IDs for traceability
- Request timing headers
- Configurable API-key security
- Configurable in-memory rate limiting
- CORS configuration
- Health/readiness endpoints
- Baseline explainability endpoint
- Structured service/repository separation
- Automated API + service tests
- Coverage and GitHub Actions CI
- Docker and Docker Compose
- OpenAPI/Swagger documentation

## Architecture
```text
Dashboard / Client
       |
       | JSON + optional X-API-Key
       v
FastAPI /api/v1
       |
       +--> Middleware: request ID / timing / rate limit
       |
       +--> Pydantic validation
       |
       +--> PredictionService
       |       +--> Churn model / baseline
       |       +--> LTV model / baseline
       |       +--> Explainability layer
       |
       +--> SQLAlchemy Repository
               |
               +--> SQLite (development)
               +--> PostgreSQL (deployment)
```

## API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Service metadata |
| GET | `/ready` | Readiness response |
| GET | `/api/v1/health` | API + DB + model status |
| POST | `/api/v1/predict/churn` | Churn probability |
| POST | `/api/v1/predict/ltv` | Estimated LTV |
| POST | `/api/v1/predict` | Combined prediction + persistence |
| POST | `/api/v1/predict/batch` | Up to 1,000 customers |
| POST | `/api/v1/explain` | Transparent baseline explanation |
| GET | `/api/v1/predictions/history` | Recent persisted predictions |

## Installation
```bash
python -m venv .venv
# Windows CMD
.venv\Scripts\activate
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Create environment configuration:
```bash
copy .env.example .env
```

Run:
```bash
uvicorn app.main:app --reload
```

Open Swagger:
`http://127.0.0.1:8000/docs`

## Example request
```json
{
  "customer_id": "CUST-1001",
  "tenure_months": 8,
  "monthly_charges": 95.5,
  "total_charges": 764,
  "contract": "Month-to-month",
  "internet_service": "Fiber optic",
  "senior_citizen": false,
  "partner": false,
  "dependents": false,
  "payment_method": "Electronic check"
}
```

### cURL
```bash
curl -X POST "http://127.0.0.1:8000/api/v1/predict"   -H "Content-Type: application/json"   -d @customer.json
```

### API key mode
Set:
```env
API_KEY_ENABLED=true
API_KEY=your-long-random-secret
```
Then send:
```text
X-API-Key: your-long-random-secret
```

## Database
Development defaults to SQLite for zero-setup testing:
```env
DATABASE_URL=sqlite:///./customer_engine.db
```
For PostgreSQL:
```env
DATABASE_URL=postgresql+psycopg2://user:password@localhost:5432/customer_engine
```

Prediction records contain request ID, customer ID, churn probability, LTV, risk segments, model source and timestamp.

## Model integration
The API checks:
```text
models/churn_model.joblib
models/ltv_model.joblib
```
If artifacts are missing, it uses a deterministic baseline so integration tests remain runnable. This is deliberately labeled `baseline`; it is not a substitute for validating the trained ML model.

For production, the recommended pattern is a scikit-learn `Pipeline` containing preprocessing + estimator, exported as one artifact. That prevents training/inference preprocessing drift.

## Testing
```bash
pytest -q
```
With coverage:
```bash
pytest --cov=app --cov-report=term-missing
```
The test suite covers health, request IDs, prediction endpoints, batch processing, persistence, validation, explainability and core scoring behavior.

## Docker
```bash
docker compose up --build
```

## CI/CD
GitHub Actions runs installation, tests and coverage on every push and pull request. This prevents an API regression from being merged without automated verification.

## Security notes
- API-key authentication is configurable and should be enabled outside local development.
- Do not commit `.env`, customer data or binary model artifacts.
- Use HTTPS behind a reverse proxy in production.
- Replace the in-memory rate limiter with Redis-backed limiting for multi-instance deployments.
- Use PostgreSQL plus migrations for production persistence.
- Add OAuth2/JWT or an API gateway when multiple users/roles are required.


## Day 6 — End-to-End Pipeline Testing & Bug Fixing

Day 6 hardens the Day 5 backend by validating the complete production path and testing failure modes, security controls, and persistence consistency.

### Day 6 completed deliverables

- End-to-end request-flow tests covering middleware → validation → prediction → database → history.
- Regression tests for all Day 5 API and service behavior.
- Boundary-value tests for zero, maximum and extreme customer inputs.
- Negative tests for missing fields, invalid enums, range violations and oversized batches.
- API-key authentication tests for both rejection and successful authorization.
- Rate-limit regression test with `Retry-After` behavior.
- Request-ID and processing-time traceability assertions.
- Atomic batch prediction persistence: a failed batch no longer leaves partial database records.
- Centralized batch transaction with rollback protection.
- Hardened request IDs with a maximum length to avoid unbounded header propagation.
- CI matrix validation on Python 3.11 and 3.12.
- Coverage XML artifact generation for CI inspection.
- Dedicated `test-e2e` and `test-regression` Makefile targets.
- `pytest.ini` test discovery/configuration for consistent local and CI execution.

### Bugs fixed during Day 6

| Area | Problem found | Fix |
|---|---|---|
| Batch persistence | Each prediction was committed independently, allowing partial history if a later prediction failed | Batch is evaluated first and persisted in one transaction with rollback |
| Rate limiting | 429 responses did not expose a standard retry hint | Added `Retry-After: 60` |
| Request tracing | Client-supplied request IDs could be arbitrarily long | IDs are capped at 128 characters |
| Regression safety | Existing tests did not verify failure-path behavior | Added E2E, security, boundary and atomicity tests |
| CI coverage | CI tested only one Python version and did not preserve coverage output | Added Python 3.11/3.12 matrix and coverage artifact |

### Day 6 verification

Run the complete suite:
```bash
pytest -q
```

Run only end-to-end tests:
```bash
make test-e2e
```

Run the regression suite:
```bash
make test-regression
```

Generate coverage:
```bash
make coverage
```

The Day 6 test suite is designed to verify not only that endpoints return `200`, but that invalid requests fail safely, predictions remain bounded, security controls work, database history is consistent, and a failed batch cannot leave partial state.


## Explainability notes
`/api/v1/explain` currently returns transparent baseline factors. It explicitly does **not** claim to be SHAP or causal analysis. Once the trained model is integrated, SHAP can be added as a separate model-explanation service and tested against the exact production pipeline.

## Recommended next development steps
1. Train and validate churn classifier.
2. Train and validate LTV regressor.
3. Export preprocessing + model pipelines.
4. Add SHAP explanation service.
5. Add Alembic migrations for PostgreSQL.
6. Add Redis-backed rate limiting/cache.
7. Add JWT/OAuth2 for production users.
8. Connect dashboard and Superset/Metabase.
9. Add model/version metadata and monitoring.
10. Deploy behind HTTPS with CI/CD and environment-specific secrets.

## Project status
**Day 6 complete — end-to-end pipeline testing, regression coverage, security testing, atomic batch persistence, and bug fixing implemented.**
