# Notebooks
Use this directory for EDA, feature engineering, model training, validation and SHAP analysis.
