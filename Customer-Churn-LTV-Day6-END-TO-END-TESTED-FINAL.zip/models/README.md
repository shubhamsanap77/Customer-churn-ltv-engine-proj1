# Model Artifacts

Optional files:
- `churn_model.joblib`
- `ltv_model.joblib`

The API automatically reports `trained` or `baseline` model status. Binary model files are ignored by Git; use Git LFS or a model registry for production artifacts.
