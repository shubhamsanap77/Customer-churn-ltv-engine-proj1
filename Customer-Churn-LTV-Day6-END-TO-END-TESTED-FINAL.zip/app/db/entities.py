from datetime import datetime, timezone
from sqlalchemy import DateTime, Float, Integer, String
from sqlalchemy.orm import Mapped, mapped_column
from app.db.database import Base

class PredictionRecord(Base):
    __tablename__ = 'prediction_records'
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    request_id: Mapped[str] = mapped_column(String(64), index=True)
    customer_id: Mapped[str] = mapped_column(String(100), index=True)
    churn_probability: Mapped[float] = mapped_column(Float)
    estimated_ltv: Mapped[float] = mapped_column(Float)
    risk_segment: Mapped[str] = mapped_column(String(20))
    ltv_segment: Mapped[str] = mapped_column(String(20))
    model_source: Mapped[str] = mapped_column(String(40))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
