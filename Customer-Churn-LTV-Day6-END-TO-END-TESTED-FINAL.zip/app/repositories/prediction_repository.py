from sqlalchemy import select
from sqlalchemy.orm import Session
from app.db.entities import PredictionRecord


def _record_from_prediction(result, request_id: str) -> PredictionRecord:
    return PredictionRecord(
        request_id=request_id,
        customer_id=result.customer_id,
        churn_probability=result.churn.churn_probability,
        estimated_ltv=result.ltv.estimated_ltv,
        risk_segment=result.churn.risk_segment,
        ltv_segment=result.ltv.ltv_segment,
        model_source=result.churn.model_source,
    )


def save_prediction(db: Session, result, request_id: str):
    row = _record_from_prediction(result, request_id)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def save_predictions(db: Session, results, request_id: str):
    """Persist a batch as one transaction so failures cannot create partial history."""
    rows = [_record_from_prediction(result, request_id) for result in results]
    try:
        db.add_all(rows)
        db.commit()
        for row in rows:
            db.refresh(row)
        return rows
    except Exception:
        db.rollback()
        raise


def recent_predictions(db: Session, limit: int = 20):
    return db.scalars(
        select(PredictionRecord)
        .order_by(PredictionRecord.created_at.desc())
        .limit(limit)
    ).all()
