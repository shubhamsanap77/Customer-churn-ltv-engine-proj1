from typing import Literal
from pydantic import BaseModel, Field

class CustomerFeatures(BaseModel):
    customer_id: str = Field(..., min_length=1, max_length=100)
    tenure_months: float = Field(..., ge=0, le=600)
    monthly_charges: float = Field(..., ge=0, le=1_000_000)
    total_charges: float = Field(..., ge=0, le=10_000_000)
    contract: Literal['Month-to-month','One year','Two year']
    internet_service: Literal['DSL','Fiber optic','No']
    senior_citizen: bool = False
    partner: bool = False
    dependents: bool = False
    payment_method: str = Field(default='Electronic check', min_length=1, max_length=100)

class ChurnPrediction(BaseModel):
    customer_id: str
    churn_probability: float = Field(..., ge=0, le=1)
    risk_segment: Literal['Low','Medium','High']
    model_source: str

class LTVPrediction(BaseModel):
    customer_id: str
    estimated_ltv: float = Field(..., ge=0)
    ltv_segment: Literal['Low','Medium','High']
    model_source: str

class CustomerPrediction(BaseModel):
    customer_id: str
    churn: ChurnPrediction
    ltv: LTVPrediction
    request_id: str | None = None

class BatchPredictionRequest(BaseModel):
    customers: list[CustomerFeatures] = Field(..., min_length=1, max_length=1000)

class BatchPredictionResponse(BaseModel):
    count: int
    predictions: list[CustomerPrediction]
    request_id: str | None = None

class ExplainResponse(BaseModel):
    customer_id: str
    base_risk: float
    factors: list[dict]
    disclaimer: str

class HistoryItem(BaseModel):
    id: int
    request_id: str
    customer_id: str
    churn_probability: float
    estimated_ltv: float
    risk_segment: str
    ltv_segment: str
    model_source: str
    created_at: str

class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    environment: str
    database: str
    model_status: dict
