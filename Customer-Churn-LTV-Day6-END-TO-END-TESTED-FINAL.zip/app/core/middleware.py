import time
import uuid
from collections import defaultdict, deque
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from app.core.config import get_settings


MAX_REQUEST_ID_LENGTH = 128


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        supplied = request.headers.get('X-Request-ID')
        request_id = (supplied[:MAX_REQUEST_ID_LENGTH] if supplied else str(uuid.uuid4()))
        request.state.request_id = request_id
        started = time.perf_counter()
        response = await call_next(request)
        response.headers['X-Request-ID'] = request_id
        response.headers['X-Process-Time-ms'] = f'{(time.perf_counter()-started)*1000:.2f}'
        return response


class InMemoryRateLimitMiddleware(BaseHTTPMiddleware):
    buckets = defaultdict(deque)

    async def dispatch(self, request: Request, call_next):
        settings = get_settings()
        if not settings.rate_limit_enabled or request.url.path in {'/', '/docs', '/openapi.json', '/redoc'}:
            return await call_next(request)

        key = request.client.host if request.client else 'unknown'
        now = time.time()
        q = self.buckets[key]
        while q and q[0] <= now - 60:
            q.popleft()

        if len(q) >= settings.rate_limit_per_minute:
            from fastapi.responses import JSONResponse
            response = JSONResponse(
                status_code=429,
                content={'detail': 'Rate limit exceeded', 'retry_after_seconds': 60},
                headers={'Retry-After': '60'},
            )
            return response

        q.append(now)
        return await call_next(request)
