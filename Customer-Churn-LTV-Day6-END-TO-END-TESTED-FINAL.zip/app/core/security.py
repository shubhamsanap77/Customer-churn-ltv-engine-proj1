from fastapi import Header, HTTPException, status
from app.core.config import get_settings

def verify_api_key(x_api_key: str | None = Header(default=None)):
    settings = get_settings()
    if not settings.api_key_enabled:
        return True
    if not x_api_key or x_api_key != settings.api_key:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid or missing API key')
    return True
