from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = 'Customer Churn & LTV Engine API'
    app_version: str = '2.0.0'
    environment: str = 'development'
    database_url: str = 'sqlite:///./customer_engine.db'
    model_path: str = 'models/churn_model.joblib'
    ltv_model_path: str = 'models/ltv_model.joblib'
    api_key_enabled: bool = False
    api_key: str = 'change-me-in-production'
    rate_limit_enabled: bool = True
    rate_limit_per_minute: int = 120
    cors_origins: str = '*'
    log_level: str = 'INFO'
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='ignore')
    @property
    def cors_origin_list(self):
        return [x.strip() for x in self.cors_origins.split(',') if x.strip()]

@lru_cache
def get_settings():
    return Settings()
