from pathlib import Path
import joblib
import numpy as np
from app.core.config import Settings
from app.models.schemas import CustomerFeatures, CustomerPrediction, ChurnPrediction, LTVPrediction

class PredictionService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.churn_model = self._load(settings.model_path)
        self.ltv_model = self._load(settings.ltv_model_path)
    @staticmethod
    def _load(path):
        p=Path(path)
        if not p.exists(): return None
        try: return joblib.load(p)
        except Exception: return None
    @staticmethod
    def _risk(p): return 'High' if p>=.70 else 'Medium' if p>=.40 else 'Low'
    @staticmethod
    def _ltv_segment(v): return 'High' if v>=5000 else 'Medium' if v>=2500 else 'Low'
    def _row(self,c):
        return [c.tenure_months,c.monthly_charges,c.total_charges,float(c.senior_citizen),float(c.partner),float(c.dependents),float(c.contract=='Month-to-month'),float(c.contract=='One year'),float(c.contract=='Two year'),float(c.internet_service=='DSL'),float(c.internet_service=='Fiber optic'),float(c.internet_service=='No')]
    def baseline_churn(self,c):
        s=.18
        s += .28 if c.contract=='Month-to-month' else .08 if c.contract=='One year' else -.08
        s += .16 if c.tenure_months<12 else -.10 if c.tenure_months>48 else 0
        s += .12 if c.monthly_charges>=90 else -.05 if c.monthly_charges<45 else 0
        s += .06 if c.internet_service=='Fiber optic' else 0
        s += .05 if c.payment_method=='Electronic check' else 0
        s += .03 if not c.dependents else 0
        return float(np.clip(s,.02,.98))
    def predict_churn(self,c):
        source='baseline'; p=None
        if self.churn_model is not None:
            try:
                x=np.asarray([self._row(c)],dtype=float)
                p=float(self.churn_model.predict_proba(x)[0][1]) if hasattr(self.churn_model,'predict_proba') else float(self.churn_model.predict(x)[0])
                source='trained_model'
            except Exception: p=None
        if p is None: p=self.baseline_churn(c)
        p=round(float(np.clip(p,0,1)),4)
        return ChurnPrediction(customer_id=c.customer_id,churn_probability=p,risk_segment=self._risk(p),model_source=source)
    def baseline_ltv(self,c):
        months=max(6,min(60,c.tenure_months*.8+18))
        multiplier={'Month-to-month':.90,'One year':1.05,'Two year':1.15}[c.contract]
        return c.monthly_charges*months*multiplier
    def predict_ltv(self,c):
        source='baseline'; v=None
        if self.ltv_model is not None:
            try: v=float(self.ltv_model.predict(np.asarray([self._row(c)],dtype=float))[0]); source='trained_model'
            except Exception: v=None
        if v is None: v=self.baseline_ltv(c)
        v=round(max(v,0),2)
        return LTVPrediction(customer_id=c.customer_id,estimated_ltv=v,ltv_segment=self._ltv_segment(v),model_source=source)
    def predict(self,c):
        return CustomerPrediction(customer_id=c.customer_id,churn=self.predict_churn(c),ltv=self.predict_ltv(c))
    def explain(self,c):
        base=self.baseline_churn(c)
        factors=[]
        if c.contract=='Month-to-month': factors.append({'feature':'contract','impact':'positive','reason':'Month-to-month contracts increase baseline churn risk.'})
        if c.tenure_months<12: factors.append({'feature':'tenure_months','impact':'positive','reason':'Short tenure increases baseline churn risk.'})
        if c.monthly_charges>=90: factors.append({'feature':'monthly_charges','impact':'positive','reason':'Higher monthly charges increase baseline churn risk.'})
        if c.internet_service=='Fiber optic': factors.append({'feature':'internet_service','impact':'positive','reason':'Fiber optic is assigned a higher baseline risk weight.'})
        if c.payment_method=='Electronic check': factors.append({'feature':'payment_method','impact':'positive','reason':'Electronic check receives a small baseline risk weight.'})
        return {'customer_id':c.customer_id,'base_risk':round(base,4),'factors':factors,'disclaimer':'Baseline feature contribution only; not SHAP and not a causal explanation.'}
