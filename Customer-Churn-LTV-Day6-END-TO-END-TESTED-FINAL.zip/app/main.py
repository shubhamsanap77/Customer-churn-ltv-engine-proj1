import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.middleware import RequestContextMiddleware, InMemoryRateLimitMiddleware
from app.db.database import init_db

settings=get_settings(); configure_logging(settings.log_level); logger=logging.getLogger('customer-engine')

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info('API started in %s mode', settings.environment)
    yield

app=FastAPI(title=settings.app_name,version=settings.app_version,description='Production-oriented REST API for customer churn risk and lifetime value integration.',lifespan=lifespan,openapi_tags=[{'name':'System','description':'Health and service diagnostics'},{'name':'Prediction','description':'Churn and LTV prediction operations'},{'name':'Explainability','description':'Transparent baseline explanations'},{'name':'Analytics','description':'Prediction history'}])
app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origin_list or ['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.add_middleware(RequestContextMiddleware); app.add_middleware(InMemoryRateLimitMiddleware)
app.include_router(router,prefix='/api/v1')


@app.get('/',tags=['System'])
def root(): return {'service':settings.app_name,'version':settings.app_version,'docs':'/docs','health':'/api/v1/health'}

@app.get('/ready',tags=['System'])
def ready(): return {'status':'ready'}

@app.exception_handler(RequestValidationError)
async def validation_handler(request:Request,exc:RequestValidationError):
    return JSONResponse(status_code=422,content={'error':'validation_error','request_id':getattr(request.state,'request_id','unknown'),'details':exc.errors()})

@app.exception_handler(Exception)
async def unhandled_handler(request:Request,exc:Exception):
    logger.exception('Unhandled exception request_id=%s',getattr(request.state,'request_id','unknown'))
    return JSONResponse(status_code=500,content={'error':'internal_server_error','request_id':getattr(request.state,'request_id','unknown'),'message':'Unexpected server error'})
