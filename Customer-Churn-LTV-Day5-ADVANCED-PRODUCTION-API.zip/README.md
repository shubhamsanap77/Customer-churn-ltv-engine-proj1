# Customer Churn Prediction & Lifetime Value Engine
## Day 5 — Advanced API / Backend Integration & Testing

This Day 5 implementation turns the original project skeleton into a structured, testable backend service suitable for connecting an ML model, dashboard, database and future deployment pipeline.

### Day 5 deliverables
- FastAPI REST backend with `/api/v1` versioning
- Pydantic validation and consistent JSON errors
- Churn prediction endpoint
- LTV prediction endpoint
- Combined prediction endpoint
- Batch prediction endpoint
- Prediction history persisted through SQLAlchemy
- SQLite development database with PostgreSQL-ready configuration
- Request IDs for traceability
- Request timing headers
- Configurable API-key security
- Configurable in-memory rate limiting
- CORS configuration
- Health/readiness endpoints
- Baseline explainability endpoint
- Structured service/repository separation
- Automated API + service tests
- Coverage and GitHub Actions CI
- Docker and Docker Compose
- OpenAPI/Swagger documentation

## Architecture
```text
Dashboard / Client
       |
       | JSON + optional X-API-Key
       v
FastAPI /api/v1
       |
       +--> Middleware: request ID / timing / rate limit
       |
       +--> Pydantic validation
       |
       +--> PredictionService
       |       +--> Churn model / baseline
       |       +--> LTV model / baseline
       |       +--> Explainability layer
       |
       +--> SQLAlchemy Repository
               |
               +--> SQLite (development)
               +--> PostgreSQL (deployment)
```

## API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Service metadata |
| GET | `/ready` | Readiness response |
| GET | `/api/v1/health` | API + DB + model status |
| POST | `/api/v1/predict/churn` | Churn probability |
| POST | `/api/v1/predict/ltv` | Estimated LTV |
| POST | `/api/v1/predict` | Combined prediction + persistence |
| POST | `/api/v1/predict/batch` | Up to 1,000 customers |
| POST | `/api/v1/explain` | Transparent baseline explanation |
| GET | `/api/v1/predictions/history` | Recent persisted predictions |

## Installation
```bash
python -m venv .venv
# Windows CMD
.venv\Scripts\activate
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Create environment configuration:
```bash
copy .env.example .env
```

Run:
```bash
uvicorn app.main:app --reload
```

Open Swagger:
`http://127.0.0.1:8000/docs`

## Example request
```json
{
  "customer_id": "CUST-1001",
  "tenure_months": 8,
  "monthly_charges": 95.5,
  "total_charges": 764,
  "contract": "Month-to-month",
  "internet_service": "Fiber optic",
  "senior_citizen": false,
  "partner": false,
  "dependents": false,
  "payment_method": "Electronic check"
}
```

### cURL
```bash
curl -X POST "http://127.0.0.1:8000/api/v1/predict"   -H "Content-Type: application/json"   -d @customer.json
```

### API key mode
Set:
```env
API_KEY_ENABLED=true
API_KEY=your-long-random-secret
```
Then send:
```text
X-API-Key: your-long-random-secret
```

## Database
Development defaults to SQLite for zero-setup testing:
```env
DATABASE_URL=sqlite:///./customer_engine.db
```
For PostgreSQL:
```env
DATABASE_URL=postgresql+psycopg2://user:password@localhost:5432/customer_engine
```

Prediction records contain request ID, customer ID, churn probability, LTV, risk segments, model source and timestamp.

## Model integration
The API checks:
```text
models/churn_model.joblib
models/ltv_model.joblib
```
If artifacts are missing, it uses a deterministic baseline so integration tests remain runnable. This is deliberately labeled `baseline`; it is not a substitute for validating the trained ML model.

For production, the recommended pattern is a scikit-learn `Pipeline` containing preprocessing + estimator, exported as one artifact. That prevents training/inference preprocessing drift.

## Testing
```bash
pytest -q
```
With coverage:
```bash
pytest --cov=app --cov-report=term-missing
```
The test suite covers health, request IDs, prediction endpoints, batch processing, persistence, validation, explainability and core scoring behavior.

## Docker
```bash
docker compose up --build
```

## CI/CD
GitHub Actions runs installation, tests and coverage on every push and pull request. This prevents an API regression from being merged without automated verification.

## Security notes
- API-key authentication is configurable and should be enabled outside local development.
- Do not commit `.env`, customer data or binary model artifacts.
- Use HTTPS behind a reverse proxy in production.
- Replace the in-memory rate limiter with Redis-backed limiting for multi-instance deployments.
- Use PostgreSQL plus migrations for production persistence.
- Add OAuth2/JWT or an API gateway when multiple users/roles are required.

## Explainability notes
`/api/v1/explain` currently returns transparent baseline factors. It explicitly does **not** claim to be SHAP or causal analysis. Once the trained model is integrated, SHAP can be added as a separate model-explanation service and tested against the exact production pipeline.

## Recommended next development steps
1. Train and validate churn classifier.
2. Train and validate LTV regressor.
3. Export preprocessing + model pipelines.
4. Add SHAP explanation service.
5. Add Alembic migrations for PostgreSQL.
6. Add Redis-backed rate limiting/cache.
7. Add JWT/OAuth2 for production users.
8. Connect dashboard and Superset/Metabase.
9. Add model/version metadata and monitoring.
10. Deploy behind HTTPS with CI/CD and environment-specific secrets.

## Project status
**Day 5 complete — API/backend integration and automated testing implemented.**
