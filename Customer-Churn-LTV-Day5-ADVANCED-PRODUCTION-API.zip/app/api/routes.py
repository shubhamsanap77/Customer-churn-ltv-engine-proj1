from fastapi import APIRouter, Depends, Request
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.core.config import Settings, get_settings
from app.core.security import verify_api_key
from app.db.database import get_db
from app.models.schemas import *
from app.repositories.prediction_repository import save_prediction, recent_predictions
from app.services.prediction_service import PredictionService

router=APIRouter()

def svc(settings: Settings=Depends(get_settings)): return PredictionService(settings)

def request_id(request: Request): return getattr(request.state,'request_id','unknown')

@router.get('/health',response_model=HealthResponse,tags=['System'])
def health(settings=Depends(get_settings),db:Session=Depends(get_db)):
    db_status='ok'
    try: db.execute(text('SELECT 1'))
    except Exception: db_status='error'
    s=PredictionService(settings)
    return HealthResponse(status='ok' if db_status=='ok' else 'degraded',service=settings.app_name,version=settings.app_version,environment=settings.environment,database=db_status,model_status={'churn': 'trained' if s.churn_model else 'baseline','ltv':'trained' if s.ltv_model else 'baseline'})

@router.post('/predict/churn',response_model=ChurnPrediction,tags=['Prediction'],dependencies=[Depends(verify_api_key)])
def churn(customer:CustomerFeatures,service=Depends(svc)): return service.predict_churn(customer)

@router.post('/predict/ltv',response_model=LTVPrediction,tags=['Prediction'],dependencies=[Depends(verify_api_key)])
def ltv(customer:CustomerFeatures,service=Depends(svc)): return service.predict_ltv(customer)

@router.post('/predict',response_model=CustomerPrediction,tags=['Prediction'],dependencies=[Depends(verify_api_key)])
def predict(customer:CustomerFeatures,request:Request,service=Depends(svc),db:Session=Depends(get_db)):
    rid=request_id(request); result=service.predict(customer); result.request_id=rid; save_prediction(db,result,rid); return result

@router.post('/predict/batch',response_model=BatchPredictionResponse,tags=['Prediction'],dependencies=[Depends(verify_api_key)])
def batch(payload:BatchPredictionRequest,request:Request,service=Depends(svc),db:Session=Depends(get_db)):
    rid=request_id(request); results=[]
    for c in payload.customers:
        r=service.predict(c); r.request_id=rid; save_prediction(db,r,rid); results.append(r)
    return BatchPredictionResponse(count=len(results),predictions=results,request_id=rid)

@router.post('/explain',response_model=ExplainResponse,tags=['Explainability'],dependencies=[Depends(verify_api_key)])
def explain(customer:CustomerFeatures,service=Depends(svc)): return service.explain(customer)

@router.get('/predictions/history',response_model=list[HistoryItem],tags=['Analytics'],dependencies=[Depends(verify_api_key)])
def history(limit:int=20,db:Session=Depends(get_db)):
    limit=max(1,min(limit,100)); rows=recent_predictions(db,limit)
    return [HistoryItem(id=x.id,request_id=x.request_id,customer_id=x.customer_id,churn_probability=x.churn_probability,estimated_ltv=x.estimated_ltv,risk_segment=x.risk_segment,ltv_segment=x.ltv_segment,model_source=x.model_source,created_at=x.created_at.isoformat()) for x in rows]
